<?php

$page_title = "Thêm sản phẩm";

$base_filename = basename(__FILE__, '.php');
$page_body_file = "$base_filename/$base_filename.body.tpl";

include 'view/_layout.php';
